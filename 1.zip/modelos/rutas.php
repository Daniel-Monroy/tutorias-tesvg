<?php

  /**
   * Rutas
   */
  class Ruta
  {

    /*=============================================>>>>>
    = RUTA DEL LADO DEL CLIENTE =
    ===============================================>>>>>*/
    public function ctrRuta(){

      return "http://localhost/tutorias2/";

    }

    /*=============================================>>>>>
    = RUTA DEL LADO DEL SERVIDOR =
    ===============================================>>>>>*/
    public function ctrRutaServidor(){

      return "http://localhost/tutoriasBack/";

    }


  }
