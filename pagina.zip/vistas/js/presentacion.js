// /*=============APLICANDO JQuery a NUESTRAS ACTIVIADES================*/
//   $('div.ocultar').hide();/*Oculta las Actividades gracias a la Clase Ocultar*/
//   $('.programa-actividades .info-actividades:first').show();/*Mostramos Los Talleres*/
//
//   $('.menu-actividades a').on('click', function(){
//     $('.ocultar').hide();
//     var enlace = $(this).attr('href'); /*Obtenemos la Referencia del enlace*/
//     $(enlace).fadeIn(1000);
//     return false;
//   })
